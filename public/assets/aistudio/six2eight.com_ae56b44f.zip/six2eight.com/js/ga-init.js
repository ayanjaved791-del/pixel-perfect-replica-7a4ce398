/**
 * GA4 stub + initial config. Loaded via next/script (external src) so it does
 * not need CSP 'unsafe-inline' / a script hash. The measurement ID comes from
 * <meta name="s28-ga-id"> published by _document — not from inline JS.
 */
;(function () {
  var meta = document.querySelector('meta[name="s28-ga-id"]')
  var id = meta && meta.content ? String(meta.content).trim() : ''
  if (!id) return

  window.__S28_GA_ID__ = id
  window.dataLayer = window.dataLayer || []
  function gtag() {
    window.dataLayer.push(arguments)
  }
  // _app tracks client-side navigations through window.gtag.
  window.gtag = gtag
  gtag('js', new Date())
  gtag('config', id, {
    page_path: window.location.pathname,
  })
})()
